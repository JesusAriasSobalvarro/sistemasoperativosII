<?php

$newuser_dn="CN=daniel,CN=Users,DC=arias,DC=com";
$newuser_password="Iwannahaveaps3#";
$adminPassword = "j2Sskhp2$Y";
$server = "arias.com";
$Administrator = "CN=Administrator,CN=Users,DC=arias,DC=com";


$ADSI = new COM("LDAP:");
$user = $ADSI->OpenDSObject("LDAP://".$server."/".$newuser_dn, $Administrator , $adminPassword, 1);
    
?>